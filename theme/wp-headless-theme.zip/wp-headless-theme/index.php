<?php
/**
 * Redirect individual post and pages to the REST API endpoint
 *
 * @package wp-headless
 */

wp_die( "There's always money in the banana stand. 🍌" );
